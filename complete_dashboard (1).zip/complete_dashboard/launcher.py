import os
import sys
import time
import socket
import threading
import webbrowser
from pathlib import Path


def resource_path(relative_path: str) -> str:
    return str(Path(__file__).resolve().parent / relative_path)


def find_free_port(start=8501, end=8599):
    for port in range(start, end + 1):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("127.0.0.1", port))
                return port
            except OSError:
                continue
    raise RuntimeError("No free port found.")


def wait_and_open_browser(port: int, timeout: float = 20.0):
    start = time.time()
    while time.time() - start < timeout:
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=1):
                webbrowser.open(f"http://127.0.0.1:{port}")
                return
        except OSError:
            time.sleep(0.5)

    webbrowser.open(f"http://127.0.0.1:{port}")


def main():
    app_path = resource_path("app.py")
    if not os.path.exists(app_path):
        raise FileNotFoundError(f"app.py not found at {app_path}")

    port = find_free_port()

    os.environ["STREAMLIT_SERVER_HEADLESS"] = "true"
    os.environ["STREAMLIT_BROWSER_GATHER_USAGE_STATS"] = "false"
    os.environ["STREAMLIT_GLOBAL_DEVELOPMENT_MODE"] = "false"

    # Auth credentials for packaged app
    os.environ["APP_USERNAME"] = "root"
    os.environ["APP_PASSWORD"] = "root"


    threading.Thread(target=wait_and_open_browser, args=(port,), daemon=True).start()

    from streamlit.web.cli import main as stcli

    sys.argv = [
        "streamlit",
        "run",
        app_path,
        "--global.developmentMode",
        "false",
        "--server.port",
        str(port),
        "--server.address",
        "127.0.0.1",
        "--server.headless",
        "true",
        "--browser.gatherUsageStats",
        "false",
        "--server.fileWatcherType",
        "none",
    ]

    stcli()


if __name__ == "__main__":
    main()