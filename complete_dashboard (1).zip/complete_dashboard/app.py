import re
from typing import Dict, List, Optional, Tuple
import numpy as np
import pandas as pd
import plotly.express as px
import streamlit as st
import os
import json
from pathlib import Path

from difflib import get_close_matches



st.set_page_config(
    page_title="Restaurant Pricing Dashboard",
    page_icon="🍽️",
    layout="wide",
)

def app_base_dir() -> Path:
    """
    Returns a writable base directory.
    In packaged exe, use the folder next to the executable.
    In normal dev mode, use the folder next to app.py.
    """
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


def load_auth_config():
    """
    Load auth from environment variables first.
    If not found, fall back to auth_config.json in app folder.
    """
    env_user = os.getenv("APP_USERNAME")
    env_pass = os.getenv("APP_PASSWORD")

    if env_user and env_pass:
        return env_user, env_pass

    config_path = app_base_dir() / "auth_config.json"
    if config_path.exists():
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                cfg = json.load(f)
            return cfg.get("APP_USERNAME", ""), cfg.get("APP_PASSWORD", "")
        except Exception:
            return "", ""

    return "", ""


def check_login():
    if "authenticated" not in st.session_state:
        st.session_state.authenticated = False

    if st.session_state.authenticated:
        return True

    st.title("🔒 Login Required")

    with st.form("login_form"):
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        submitted = st.form_submit_button("Login")

    if submitted:
        expected_username, expected_password = load_auth_config()
        if not expected_username or not expected_password:
            st.error("Login configuration not found. Please set APP_USERNAME/APP_PASSWORD or provide auth_config.json.")
            return False

        if username == expected_username and password == expected_password:
            st.session_state.authenticated = True
            st.success("Login successful.")
            st.rerun()
        else:
            st.error("Invalid username or password.")

    return False

if not check_login():
    st.stop()

# =========================================================
# CONFIG
# =========================================================

TIER_ORDER = ["Budget", "Mid-range", "Premium"]

TIER_COLORS = {
    "Budget": "#2ca02c",
    "Mid-range": "#ff7f0e",
    "Premium": "#d62728",
    "Missing": "#7f7f7f",
}

CANONICAL_ALIASES = {
    "restaurant_id": ["restaurant id", "rest id", "id"],
    "serial_no": ["#", "serial no", "serial number", "s no"],
    "restaurant_name": ["restaurant name", "name"],
    "locality": ["locality", "neighbourhood", "neighborhood", "area"],
    "cuisine_type": ["cuisine type", "cuisine", "category"],
    "source": ["source", "platform", "listing source"],
    "bfast_min": ["bfast min", "breakfast min", "bf min"],
    "bfast_max": ["bfast max", "breakfast max", "bf max"],
    "lunch_min": ["lunch min"],
    "lunch_max": ["lunch max"],
    "din_min": ["din min", "dinner min"],
    "din_max": ["din max", "dinner max"],
    "seating": ["seating", "capacity", "seating capacity"],
    "rating": ["rating", "ratings"],
    "date": ["date", "collection date", "date collected"],
    "bfast_avg": ["bfast avg", "breakfast avg", "bf avg"],
    "lunch_avg": ["lunch avg"],
    "din_avg": ["din avg", "dinner avg"],
    "overall_avg": ["overall avg", "avg overall", "overall average"],
    "bfast_tier": ["bfast tier", "breakfast tier"],
    "lunch_tier": ["lunch tier"],
    "din_tier": ["din tier", "dinner tier"],
    "overall_tier": ["overall tier", "tier", "final tier"],
    "bfast_available": ["bfast?", "breakfast?", "breakfast available", "bfast available"],
}

HEADER_SIGNALS = [
    "restaurant id",
    "restaurant name",
    "locality",
    "cuisine type",
    "source",
    "rating",
    "overall tier",
]

DEFAULT_CUTOFFS = {
    "Breakfast": {"Budget": (0, 150), "Mid-range": (150, 350), "Premium": (350, np.inf)},
    "Lunch": {"Budget": (0, 250), "Mid-range": (250, 500), "Premium": (500, np.inf)},
    "Dinner": {"Budget": (0, 300), "Mid-range": (300, 600), "Premium": (600, np.inf)},
    "Overall": {"Budget": (0, 250), "Mid-range": (250, 500), "Premium": (500, np.inf)},
}


# =========================================================
# UTILS
# =========================================================

def clean_col_name(col: str) -> str:
    if col is None:
        return ""
    col = str(col).strip().lower()
    col = re.sub(r"\s+", " ", col)
    return col


def standardize_text(x):
    if pd.isna(x):
        return np.nan
    s = str(x).strip()
    if s in {"", "-", "—", "nan", "None", "none"}:
        return np.nan
    return s


def to_numeric_value(x):
    if pd.isna(x):
        return np.nan
    s = str(x).strip()
    if s in {"", "-", "—", "nan", "None", "none"}:
        return np.nan
    s = s.replace("₹", "").replace(",", "").strip()
    try:
        return float(s)
    except Exception:
        return np.nan


def to_numeric_series(series: pd.Series) -> pd.Series:
    return series.apply(to_numeric_value)


def find_header_row(raw_df: pd.DataFrame, max_scan_rows: int = 25) -> int:
    """
    Detect the actual header row by scoring rows containing header-like terms.
    """
    best_row = 0
    best_score = -1
    max_rows = min(max_scan_rows, len(raw_df))

    for i in range(max_rows):
        vals = [clean_col_name(v) for v in raw_df.iloc[i].tolist()]
        row_text = " | ".join(vals)
        score = sum(signal in row_text for signal in HEADER_SIGNALS)
        if score > best_score:
            best_score = score
            best_row = i

    return best_row


def build_column_map(df: pd.DataFrame) -> Dict[str, str]:
    normalized_actual = {clean_col_name(c): c for c in df.columns}
    mapping = {}

    for canonical, aliases in CANONICAL_ALIASES.items():
        for alias in aliases:
            alias_clean = clean_col_name(alias)
            if alias_clean in normalized_actual:
                mapping[canonical] = normalized_actual[alias_clean]
                break

    return mapping


def ensure_required_columns(df: pd.DataFrame) -> pd.DataFrame:
    for canonical in CANONICAL_ALIASES.keys():
        if canonical not in df.columns:
            df[canonical] = np.nan
    return df


def safe_mode(series: pd.Series):
    s = series.dropna()
    if s.empty:
        return np.nan
    mode_vals = s.mode()
    return mode_vals.iloc[0] if not mode_vals.empty else np.nan


def tier_from_cutoff(value, cutoff_dict):
    if pd.isna(value):
        return np.nan
    for tier, (low, high) in cutoff_dict.items():
        if low <= value < high:
            return tier
    return np.nan


def normalize_tier(x):
    if pd.isna(x):
        return np.nan
    s = str(x).strip().lower()
    if s in {"budget"}:
        return "Budget"
    if s in {"mid-range", "mid range", "midrange"}:
        return "Mid-range"
    if s in {"premium"}:
        return "Premium"
    return np.nan


def format_currency(val) -> str:
    if pd.isna(val):
        return "NA"
    return f"₹{val:,.1f}"


def show_tier_legend():
    st.markdown(
        """
        **Tier Legend**  
        🟢 Budget &nbsp;&nbsp; | &nbsp;&nbsp; 🟠 Mid-range &nbsp;&nbsp; | &nbsp;&nbsp; 🔴 Premium
        """
    )


def build_name_suggestions(names: List[str], query: str, max_suggestions: int = 8) -> List[str]:
    """
    Returns closest / relevant restaurant name suggestions after user types 2+ chars.
    Combines prefix, substring, and fuzzy matching.
    """
    if not query:
        return []

    query = query.strip().lower()
    if len(query) < 2:
        return []

    clean_names = [n for n in names if isinstance(n, str) and n.strip()]
    names_lower_map = {n.lower(): n for n in clean_names}

    # 1. prefix matches
    prefix_matches = [n for n in clean_names if n.lower().startswith(query)]

    # 2. substring matches
    substring_matches = [n for n in clean_names if query in n.lower() and n not in prefix_matches]

    # 3. fuzzy matches
    fuzzy_lower = get_close_matches(query, list(names_lower_map.keys()), n=max_suggestions, cutoff=0.35)
    fuzzy_matches = [names_lower_map[n] for n in fuzzy_lower if names_lower_map[n] not in prefix_matches and names_lower_map[n] not in substring_matches]

    combined = prefix_matches + substring_matches + fuzzy_matches
    return combined[:max_suggestions]


def render_name_search(df: pd.DataFrame) -> pd.DataFrame:
    """
    Search UI with live suggestions after 2 characters.
    Returns filtered dataframe.
    """
    st.sidebar.subheader("Restaurant Name Search")

    all_names = sorted(df["restaurant_name"].dropna().astype(str).unique().tolist())
    typed_query = st.sidebar.text_input("Type restaurant name")

    selected_name = None

    if typed_query and len(typed_query.strip()) >= 2:
        suggestions = build_name_suggestions(all_names, typed_query)

        if suggestions:
            selected_name = st.sidebar.selectbox(
                "Suggestions",
                options=["-- Select a suggestion --"] + suggestions,
                index=0,
                key="restaurant_name_suggestion_box"
            )
        else:
            st.sidebar.caption("No close matches found.")

    out = df.copy()

    if typed_query:
        out = out[out["restaurant_name"].astype(str).str.contains(typed_query, case=False, na=False)]

    if selected_name and selected_name != "-- Select a suggestion --":
        out = df[df["restaurant_name"] == selected_name].copy()

    return out


def render_name_search_single_box(df: pd.DataFrame) -> pd.DataFrame:
    """
    Native Streamlit single-box restaurant search.
    Uses selectbox with built-in type-to-search.
    No separate suggestions field.
    """
    st.sidebar.subheader("Restaurant Name Search")

    all_names = sorted(df["restaurant_name"].dropna().astype(str).unique().tolist())

    selected_name = st.sidebar.selectbox(
        "Type or select restaurant",
        options=["All Restaurants"] + all_names,
        index=0,
        help="Start typing after clicking the dropdown to search restaurant names."
    )

    if selected_name != "All Restaurants":
        return df[df["restaurant_name"] == selected_name].copy()

    return df.copy()


def metric_card(title: str, value: str, subtitle: str = "", color: str = "#1f2937", bg: str = "#f8fafc"):
    st.markdown(
        f"""
        <div style="
            background: {bg};
            padding: 20px 18px;
            border-radius: 18px;
            border: 1px solid rgba(148, 163, 184, 0.22);
            box-shadow: 0 4px 14px rgba(15, 23, 42, 0.05);
            min-height: 126px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            margin-bottom: 6px;
        ">
            <div style="
                font-size: 0.92rem;
                color: #64748b;
                font-weight: 600;
                margin-bottom: 10px;
                letter-spacing: 0.2px;
            ">
                {title}
            </div>
            <div style="
                font-size: 2.1rem;
                font-weight: 800;
                color: {color};
                line-height: 1.05;
                margin-bottom: 8px;
            ">
                {value}
            </div>
            <div style="
                font-size: 0.82rem;
                color: #94a3b8;
                line-height: 1.35;
            ">
                {subtitle}
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )
# =========================================================
# DATA LOADING
# =========================================================

@st.cache_data(show_spinner=False)
def load_restaurant_data(uploaded_file, sheet_name: str = "DATA") -> Tuple[pd.DataFrame, Dict]:
    uploaded_file.seek(0)
    excel = pd.ExcelFile(uploaded_file)

    if sheet_name not in excel.sheet_names:
        raise ValueError(f"Sheet '{sheet_name}' not found. Available sheets: {excel.sheet_names}")

    uploaded_file.seek(0)
    raw_df = pd.read_excel(uploaded_file, sheet_name=sheet_name, header=None)

    header_row = find_header_row(raw_df)
    headers = raw_df.iloc[header_row].tolist()

    # Extract title/meta text from rows above header
    title_text = None
    subtitle_text = None

    if header_row >= 1:
        row0_vals = [str(v).strip() for v in raw_df.iloc[0].tolist() if pd.notna(v) and str(v).strip()]
        if row0_vals:
            title_text = row0_vals[0]

    if header_row >= 2:
        row1_vals = [str(v).strip() for v in raw_df.iloc[1].tolist() if pd.notna(v) and str(v).strip()]
        if row1_vals:
            subtitle_text = " | ".join(row1_vals)

    df = raw_df.iloc[header_row + 1 :].copy()
    df.columns = headers
    df = df.reset_index(drop=True)
    df = df.dropna(how="all").copy()

    df = df.loc[:, ~pd.Index(df.columns).duplicated(keep="first")].copy()

    for c in df.columns:
        df[c] = df[c].apply(standardize_text)

    col_map = build_column_map(df)
    rename_map = {orig: canon for canon, orig in col_map.items()}
    df = df.rename(columns=rename_map).copy()
    df = df.loc[:, ~pd.Index(df.columns).duplicated(keep="first")].copy()
    df = ensure_required_columns(df)

    df["restaurant_id"] = df["restaurant_id"].apply(standardize_text)
    df = df[df["restaurant_id"].astype(str).str.match(r"^R\d+$", na=False)].copy()

    numeric_cols = [
        "serial_no", "bfast_min", "bfast_max", "lunch_min", "lunch_max",
        "din_min", "din_max", "seating", "rating",
        "bfast_avg", "lunch_avg", "din_avg", "overall_avg"
    ]
    for col in numeric_cols:
        df[col] = to_numeric_series(df[col])

    text_cols = [
        "restaurant_name", "locality", "cuisine_type", "source",
        "bfast_tier", "lunch_tier", "din_tier", "overall_tier", "bfast_available"
    ]
    for col in text_cols:
        df[col] = df[col].apply(standardize_text)

    df["date"] = pd.to_datetime(df["date"], errors="coerce")

    for col in ["bfast_tier", "lunch_tier", "din_tier", "overall_tier"]:
        df[col] = df[col].apply(normalize_tier)

    if df["bfast_avg"].isna().all():
        df["bfast_avg"] = df[["bfast_min", "bfast_max"]].mean(axis=1)
    if df["lunch_avg"].isna().all():
        df["lunch_avg"] = df[["lunch_min", "lunch_max"]].mean(axis=1)
    if df["din_avg"].isna().all():
        df["din_avg"] = df[["din_min", "din_max"]].mean(axis=1)
    if df["overall_avg"].isna().all():
        df["overall_avg"] = df[["bfast_avg", "lunch_avg", "din_avg"]].mean(axis=1, skipna=True)

    if df["bfast_tier"].isna().all():
        df["bfast_tier"] = df["bfast_avg"].apply(lambda v: tier_from_cutoff(v, DEFAULT_CUTOFFS["Breakfast"]))
    if df["lunch_tier"].isna().all():
        df["lunch_tier"] = df["lunch_avg"].apply(lambda v: tier_from_cutoff(v, DEFAULT_CUTOFFS["Lunch"]))
    if df["din_tier"].isna().all():
        df["din_tier"] = df["din_avg"].apply(lambda v: tier_from_cutoff(v, DEFAULT_CUTOFFS["Dinner"]))
    if df["overall_tier"].isna().all():
        df["overall_tier"] = df["overall_avg"].apply(lambda v: tier_from_cutoff(v, DEFAULT_CUTOFFS["Overall"]))

    if df["bfast_available"].isna().all():
        df["bfast_available"] = np.where(df["bfast_avg"].notna(), "Yes", "No")
    else:
        df["bfast_available"] = df["bfast_available"].replace({"yes": "Yes", "no": "No", "Yes": "Yes", "No": "No"})

    df["bfast_spread"] = df["bfast_max"] - df["bfast_min"]
    df["lunch_spread"] = df["lunch_max"] - df["lunch_min"]
    df["din_spread"] = df["din_max"] - df["din_min"]
    df["lunch_minus_bfast"] = df["lunch_avg"] - df["bfast_avg"]
    df["din_minus_lunch"] = df["din_avg"] - df["lunch_avg"]

    df["rating_price_score"] = np.where(
        df["overall_avg"].notna() & (df["overall_avg"] != 0),
        df["rating"] / df["overall_avg"],
        np.nan,
    )

    for col in ["bfast_tier", "lunch_tier", "din_tier", "overall_tier"]:
        df[col] = pd.Categorical(df[col], categories=TIER_ORDER, ordered=True)

    meta = {
        "sheet_used": sheet_name,
        "header_row_detected": int(header_row),
        "record_count": int(len(df)),
        "title_text": title_text,
        "subtitle_text": subtitle_text,
    }

    return df, meta


# =========================================================
# FILTERS
# =========================================================

def filter_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    st.sidebar.header("Filters")

    # Single-box native search
    out = render_name_search_single_box(df)

    locality_options = sorted([x for x in out["locality"].dropna().unique().tolist()])
    cuisine_options = sorted([x for x in out["cuisine_type"].dropna().unique().tolist()])
    source_options = sorted([x for x in out["source"].dropna().unique().tolist()])

    localities = st.sidebar.multiselect("Locality", locality_options)
    cuisines = st.sidebar.multiselect("Cuisine Type", cuisine_options)
    sources = st.sidebar.multiselect("Source", source_options)
    overall_tiers = st.sidebar.multiselect("Overall Tier", TIER_ORDER)
    breakfast_choice = st.sidebar.selectbox("Breakfast Availability", ["All", "Yes", "No"])

    if localities:
        out = out[out["locality"].isin(localities)]

    if cuisines:
        out = out[out["cuisine_type"].isin(cuisines)]

    if sources:
        out = out[out["source"].isin(sources)]

    if overall_tiers:
        out = out[out["overall_tier"].astype(str).isin(overall_tiers)]

    if breakfast_choice != "All":
        out = out[out["bfast_available"].astype(str).str.lower() == breakfast_choice.lower()]

    include_missing_rating = st.sidebar.checkbox("Include missing ratings", value=True)
    include_missing_price = st.sidebar.checkbox("Include missing overall price", value=True)

    # -----------------------------
    # Rating filter (safe slider)
    # -----------------------------
    rating_non_null = out["rating"].dropna()

    apply_rating_filter = False
    rating_range = None

    if rating_non_null.empty:
        st.sidebar.caption("Rating Range: no rating data in current selection.")
    else:
        rating_min = float(rating_non_null.min())
        rating_max = float(rating_non_null.max())

        if rating_min == rating_max:
            st.sidebar.caption(f"Rating Range: fixed at {rating_min:.1f}")
        else:
            rating_range = st.sidebar.slider(
                "Rating Range",
                min_value=float(np.floor(rating_min * 10) / 10),
                max_value=float(np.ceil(rating_max * 10) / 10),
                value=(
                    float(np.floor(rating_min * 10) / 10),
                    float(np.ceil(rating_max * 10) / 10),
                ),
                step=0.1,
            )
            apply_rating_filter = True

    # -----------------------------
    # Price filter (safe slider)
    # -----------------------------
    price_non_null = out["overall_avg"].dropna()

    apply_price_filter = False
    price_range = None

    if price_non_null.empty:
        st.sidebar.caption("Overall Avg Price: no price data in current selection.")
    else:
        price_min = float(price_non_null.min())
        price_max = float(price_non_null.max())

        if price_min == price_max:
            st.sidebar.caption(f"Overall Avg Price: fixed at ₹{price_min:,.1f}")
        else:
            price_range = st.sidebar.slider(
                "Overall Avg Price",
                min_value=float(price_min),
                max_value=float(price_max),
                value=(float(price_min), float(price_max)),
                step=10.0,
            )
            apply_price_filter = True

    # Apply rating filter only if slider exists
    if apply_rating_filter and rating_range is not None:
        if include_missing_rating:
            out = out[
                out["rating"].isna() |
                (
                    (out["rating"] >= rating_range[0]) &
                    (out["rating"] <= rating_range[1])
                )
            ]
        else:
            out = out[
                out["rating"].notna() &
                (out["rating"] >= rating_range[0]) &
                (out["rating"] <= rating_range[1])
            ]

    # Apply price filter only if slider exists
    if apply_price_filter and price_range is not None:
        if include_missing_price:
            out = out[
                out["overall_avg"].isna() |
                (
                    (out["overall_avg"] >= price_range[0]) &
                    (out["overall_avg"] <= price_range[1])
                )
            ]
        else:
            out = out[
                out["overall_avg"].notna() &
                (out["overall_avg"] >= price_range[0]) &
                (out["overall_avg"] <= price_range[1])
            ]

    return out.copy()
# =========================================================
# SUMMARIES
# =========================================================

def make_kpis(df: pd.DataFrame) -> Dict[str, float]:
    return {
        "restaurants": int(len(df)),
        "localities": int(df["locality"].nunique(dropna=True)),
        "cuisines": int(df["cuisine_type"].nunique(dropna=True)),
        "avg_rating": round(df["rating"].mean(), 2) if df["rating"].notna().any() else np.nan,
        "avg_overall": round(df["overall_avg"].mean(), 1) if df["overall_avg"].notna().any() else np.nan,
        "budget": int((df["overall_tier"].astype(str) == "Budget").sum()),
        "mid": int((df["overall_tier"].astype(str) == "Mid-range").sum()),
        "premium": int((df["overall_tier"].astype(str) == "Premium").sum()),
        "bfast_yes": int((df["bfast_available"].astype(str).str.lower() == "yes").sum()),
    }


def locality_summary(df: pd.DataFrame) -> pd.DataFrame:
    out = df.groupby("locality", dropna=True).agg(
        restaurant_count=("restaurant_id", "count"),
        avg_rating=("rating", "mean"),
        avg_overall_price=("overall_avg", "mean"),
        budget_count=("overall_tier", lambda s: (s.astype(str) == "Budget").sum()),
        mid_count=("overall_tier", lambda s: (s.astype(str) == "Mid-range").sum()),
        premium_count=("overall_tier", lambda s: (s.astype(str) == "Premium").sum()),
    ).reset_index()

    return out.sort_values(["restaurant_count", "avg_overall_price"], ascending=[False, False])


def cuisine_summary(df: pd.DataFrame) -> pd.DataFrame:
    out = df.groupby("cuisine_type", dropna=True).agg(
        restaurant_count=("restaurant_id", "count"),
        avg_rating=("rating", "mean"),
        avg_overall_price=("overall_avg", "mean"),
        dominant_tier=("overall_tier", safe_mode),
    ).reset_index()

    return out.sort_values(["restaurant_count", "avg_overall_price"], ascending=[False, False])


def meal_tier_distribution(df: pd.DataFrame) -> pd.DataFrame:
    frames = []
    meal_map = {
        "Breakfast": "bfast_tier",
        "Lunch": "lunch_tier",
        "Dinner": "din_tier",
    }

    for meal_name, tier_col in meal_map.items():
        temp = df.groupby(tier_col, dropna=False).size().reset_index(name="count")
        temp = temp.rename(columns={tier_col: "tier"})
        temp["Meal"] = meal_name
        frames.append(temp)

    out = pd.concat(frames, ignore_index=True)
    out["tier"] = out["tier"].astype(str).replace("nan", "Missing")
    return out


# =========================================================
# RENDERERS
# =========================================================

def render_empty_state():
    st.warning("No records match the selected filters.")


def render_overview(df: pd.DataFrame):
    if df.empty:
        render_empty_state()
        return

    show_tier_legend()
    kpi = make_kpis(df)

    st.subheader("Overview")
    st.markdown(
    """
    <div style="
        padding: 14px 18px;
        border-radius: 16px;
        background: linear-gradient(90deg, #fff7ed 0%, #eff6ff 100%);
        border: 1px solid rgba(148, 163, 184, 0.18);
        margin-bottom: 16px;
        font-size: 0.98rem;
        color: #475569;
        font-weight: 500;
    ">
        Snapshot of restaurant pricing, tier distribution, locality spread, and cuisine coverage for the current filtered view.
    </div>
    """,
    unsafe_allow_html=True,)

    row1 = st.columns(5, gap="medium")
    with row1[0]:
        metric_card("Restaurants", f"{kpi['restaurants']}", "Total restaurants in current view", color="#0f172a", bg="#f8fafc")
    with row1[1]:
        metric_card("Localities", f"{kpi['localities']}", "Unique localities covered", color="#0f172a", bg="#f8fafc")
    with row1[2]:
        metric_card("Cuisine Types", f"{kpi['cuisines']}", "Distinct cuisine categories", color="#0f172a", bg="#f8fafc")
    with row1[3]:
        metric_card("Avg Rating", f"{kpi['avg_rating']}", "Average rating of filtered restaurants", color="#1d4ed8", bg="#eff6ff")
    with row1[4]:
        metric_card("Avg Overall Price", f"{format_currency(kpi['avg_overall'])}", "Mean overall price per restaurant", color="#7c3aed", bg="#f5f3ff")

    st.markdown("<div style='height: 14px;'></div>", unsafe_allow_html=True)

    row2 = st.columns(4, gap="medium")
    with row2[0]:
        metric_card("Budget", f"{kpi['budget']}", "Restaurants in budget tier", color="#15803d", bg="#f0fdf4")
    with row2[1]:
        metric_card("Mid-range", f"{kpi['mid']}", "Restaurants in mid-range tier", color="#c2410c", bg="#fff7ed")
    with row2[2]:
        metric_card("Premium", f"{kpi['premium']}", "Restaurants in premium tier", color="#b91c1c", bg="#fef2f2")
    with row2[3]:
        metric_card("Breakfast Available", f"{kpi['bfast_yes']}", "Restaurants serving breakfast", color="#0f766e", bg="#f0fdfa")

    left, right = st.columns(2)

    with left:
        tier_counts = (
            df["overall_tier"]
            .astype(str)
            .replace("nan", np.nan)
            .dropna()
            .value_counts()
            .reindex(TIER_ORDER, fill_value=0)
            .reset_index()
        )
        tier_counts.columns = ["Tier", "Count"]

        fig = px.bar(
            tier_counts,
            x="Tier",
            y="Count",
            color="Tier",
            color_discrete_map=TIER_COLORS,
            title="Overall Tier Distribution",
        )
        st.plotly_chart(fig, width='stretch')

    with right:
        meal_avg = pd.DataFrame({
            "Meal": ["Breakfast", "Lunch", "Dinner"],
            "Average Price": [
                df["bfast_avg"].mean(),
                df["lunch_avg"].mean(),
                df["din_avg"].mean(),
            ],
        }).dropna()

        fig = px.bar(
            meal_avg,
            x="Meal",
            y="Average Price",
            title="Meal-wise Average Price",
        )
        st.plotly_chart(fig, width='stretch')

    left, right = st.columns(2)

    with left:
        fig = px.histogram(
            df.dropna(subset=["overall_avg"]),
            x="overall_avg",
            nbins=20,
            title="Distribution of Overall Average Price",
        )
        st.plotly_chart(fig, width='stretch')

    with right:
        scatter_df = df.dropna(subset=["overall_avg", "rating"]).copy()
        fig = px.scatter(
            scatter_df,
            x="overall_avg",
            y="rating",
            color="overall_tier",
            hover_name="restaurant_name",
            color_discrete_map=TIER_COLORS,
            title="Rating vs Overall Average Price",
        )
        st.plotly_chart(fig, width='stretch')


def render_meal_analysis(df: pd.DataFrame):
    if df.empty:
        render_empty_state()
        return

    show_tier_legend()
    st.subheader("Meal Analysis")

    meal_dist = meal_tier_distribution(df)
    fig = px.bar(
        meal_dist,
        x="Meal",
        y="count",
        color="tier",
        barmode="group",
        color_discrete_map=TIER_COLORS,
        title="Meal-wise Tier Comparison",
    )
    st.plotly_chart(fig, width='stretch')

    c1, c2 = st.columns(2)

    with c1:
        long_df = pd.DataFrame({
            "Meal": np.repeat(["Breakfast", "Lunch", "Dinner"], len(df)),
            "Price": pd.concat(
                [df["bfast_avg"], df["lunch_avg"], df["din_avg"]],
                ignore_index=True,
            ),
        }).dropna()

        fig = px.box(
            long_df,
            x="Meal",
            y="Price",
            title="Meal-wise Price Spread",
        )
        st.plotly_chart(fig, width='stretch')

    with c2:
        spread_df = pd.DataFrame({
            "Meal": ["Breakfast", "Lunch", "Dinner"],
            "Average Spread": [
                df["bfast_spread"].mean(),
                df["lunch_spread"].mean(),
                df["din_spread"].mean(),
            ],
        }).dropna()

        fig = px.bar(
            spread_df,
            x="Meal",
            y="Average Spread",
            title="Average Min-Max Spread by Meal",
        )
        st.plotly_chart(fig, width='stretch')

    c3, c4 = st.columns(2)

    with c3:
        jump1 = (
            df[["restaurant_name", "lunch_minus_bfast"]]
            .dropna()
            .sort_values("lunch_minus_bfast", ascending=False)
            .head(10)
        )
        fig = px.bar(
            jump1,
            x="lunch_minus_bfast",
            y="restaurant_name",
            orientation="h",
            title="Top Lunch Jump vs Breakfast",
        )
        st.plotly_chart(fig, width='stretch')

    with c4:
        jump2 = (
            df[["restaurant_name", "din_minus_lunch"]]
            .dropna()
            .sort_values("din_minus_lunch", ascending=False)
            .head(10)
        )
        fig = px.bar(
            jump2,
            x="din_minus_lunch",
            y="restaurant_name",
            orientation="h",
            title="Top Dinner Jump vs Lunch",
        )
        st.plotly_chart(fig, width='stretch')


def render_locality_analysis(df: pd.DataFrame):
    if df.empty:
        render_empty_state()
        return

    show_tier_legend()
    st.subheader("Locality Analysis")

    loc = locality_summary(df).copy()

    if loc.empty:
        st.warning("No locality-level data available.")
        return

    c0, c00 = st.columns(2)

    with c0:
        if len(loc) == 1:
            top_n = 1
            st.caption("Only 1 locality available in current selection.")
        else:
            min_top_n = 1
            max_top_n = min(30, len(loc))
            default_top_n = min(15, len(loc))

            top_n = st.slider(
                "Top localities to show",
                min_value=min_top_n,
                max_value=max_top_n,
                value=default_top_n,
            )

    with c00:
        sort_metric = st.selectbox(
            "Sort localities by",
            ["restaurant_count", "avg_overall_price", "avg_rating", "premium_count", "budget_count"],
            index=0
        )

    loc_top = loc.sort_values(sort_metric, ascending=False).head(top_n).copy()

    c1, c2 = st.columns(2)

    with c1:
        fig = px.bar(
            loc_top.sort_values("restaurant_count", ascending=True),
            x="restaurant_count",
            y="locality",
            orientation="h",
            title="Restaurant Count by Locality",
            hover_data=["avg_rating", "avg_overall_price", "budget_count", "mid_count", "premium_count"]
        )
        st.plotly_chart(fig, width='stretch')

    with c2:
        fig = px.bar(
            loc_top.sort_values("avg_overall_price", ascending=True),
            x="avg_overall_price",
            y="locality",
            orientation="h",
            title="Average Overall Price by Locality",
            hover_data=["restaurant_count", "avg_rating", "budget_count", "mid_count", "premium_count"]
        )
        st.plotly_chart(fig, width='stretch')

    tier_loc = (
        df.groupby(["locality", "overall_tier"], dropna=False)
        .size()
        .reset_index(name="count")
    )

    fig = px.bar(
        tier_loc,
        x="locality",
        y="count",
        color="overall_tier",
        barmode="stack",
        color_discrete_map=TIER_COLORS,
        title="Tier Mix by Locality",
    )
    st.plotly_chart(fig, width='stretch')

    st.markdown("### Interactive Bubble Chart")

    bubble = loc.copy()
    bubble["premium_ratio"] = np.where(
        bubble["restaurant_count"] > 0,
        bubble["premium_count"] / bubble["restaurant_count"],
        0
    )
    bubble["budget_ratio"] = np.where(
        bubble["restaurant_count"] > 0,
        bubble["budget_count"] / bubble["restaurant_count"],
        0
    )

    bubble_x_options = ["avg_overall_price", "avg_rating", "restaurant_count", "premium_count", "budget_count"]
    bubble_y_options = ["avg_rating", "avg_overall_price", "restaurant_count", "premium_count", "budget_count"]
    bubble_size_options = ["restaurant_count", "premium_count", "budget_count", "mid_count"]
    bubble_color_options = ["avg_overall_price", "avg_rating", "restaurant_count", "premium_count", "budget_count", "mid_count"]

    b1, b2, b3 = st.columns(3)

    with b1:
        bubble_x = st.selectbox("X-axis", bubble_x_options, index=0, key="loc_bubble_x")
    with b2:
        bubble_y = st.selectbox("Y-axis", bubble_y_options, index=0, key="loc_bubble_y")
    with b3:
        bubble_size = st.selectbox("Bubble size", bubble_size_options, index=0, key="loc_bubble_size")

    bubble_color = st.selectbox("Bubble color", bubble_color_options, index=0, key="loc_bubble_color")

    bubble_plot = bubble.dropna(subset=[bubble_x, bubble_y]).copy()

    if bubble_plot.empty:
        st.warning("No data available for the current bubble chart selection.")
    else:
        fig = px.scatter(
            bubble_plot,
            x=bubble_x,
            y=bubble_y,
            size=bubble_size,
            color=bubble_color,
            hover_name="locality",
            hover_data=[
                "restaurant_count",
                "avg_rating",
                "avg_overall_price",
                "budget_count",
                "mid_count",
                "premium_count",
                "premium_ratio",
                "budget_ratio",
            ],
            title=f"Bubble Chart: {bubble_y} vs {bubble_x}",
        )

        fig.update_traces(
            marker=dict(sizemode="area", line=dict(width=1, color="DarkSlateGrey"))
        )

        st.plotly_chart(fig, width='stretch')

    st.dataframe(loc, width='stretch', hide_index=True)


def render_cuisine_analysis(df: pd.DataFrame):
    if df.empty:
        render_empty_state()
        return

    show_tier_legend()
    st.subheader("Cuisine Analysis")

    cui = cuisine_summary(df).copy()

    if cui.empty:
        st.warning("No cuisine-level data available.")
        return

    if len(cui) == 1:
        st.caption("Only 1 cuisine type available in current selection.")
        cui_top = cui.copy()
    else:
        top_n = min(15, len(cui))
        cui_top = cui.head(top_n).copy()

    c1, c2 = st.columns(2)

    with c1:
        fig = px.bar(
            cui_top.sort_values("restaurant_count", ascending=True),
            x="restaurant_count",
            y="cuisine_type",
            orientation="h",
            title="Restaurant Count by Cuisine Type",
            hover_data=["avg_rating", "avg_overall_price", "dominant_tier"]
        )
        st.plotly_chart(fig, width='stretch')

    with c2:
        fig = px.bar(
            cui_top.sort_values("avg_overall_price", ascending=True),
            x="avg_overall_price",
            y="cuisine_type",
            orientation="h",
            title="Average Overall Price by Cuisine Type",
            hover_data=["restaurant_count", "avg_rating", "dominant_tier"]
        )
        st.plotly_chart(fig, width='stretch')

    tier_cui = (
        df.groupby(["cuisine_type", "overall_tier"], dropna=False)
        .size()
        .reset_index(name="count")
    )

    fig = px.bar(
        tier_cui,
        x="cuisine_type",
        y="count",
        color="overall_tier",
        barmode="stack",
        color_discrete_map=TIER_COLORS,
        title="Tier Mix by Cuisine Type",
    )
    st.plotly_chart(fig, width='stretch')

    st.markdown("### Interactive Cuisine Bubble Chart")

    bubble_df = (
        df.groupby("cuisine_type", dropna=True)
        .agg(
            restaurant_count=("restaurant_id", "count"),
            avg_rating=("rating", "mean"),
            avg_overall_price=("overall_avg", "mean"),
            budget_count=("overall_tier", lambda s: (s.astype(str) == "Budget").sum()),
            mid_count=("overall_tier", lambda s: (s.astype(str) == "Mid-range").sum()),
            premium_count=("overall_tier", lambda s: (s.astype(str) == "Premium").sum()),
        )
        .reset_index()
    )

    if bubble_df.empty:
        st.warning("No cuisine bubble chart data available.")
    else:
        bx1, bx2, bx3 = st.columns(3)
        with bx1:
            bubble_x = st.selectbox(
                "Cuisine X-axis",
                ["avg_overall_price", "avg_rating", "restaurant_count"],
                index=0,
                key="cui_bubble_x"
            )
        with bx2:
            bubble_y = st.selectbox(
                "Cuisine Y-axis",
                ["avg_rating", "avg_overall_price", "restaurant_count"],
                index=0,
                key="cui_bubble_y"
            )
        with bx3:
            bubble_size = st.selectbox(
                "Cuisine bubble size",
                ["restaurant_count", "premium_count", "budget_count", "mid_count"],
                index=0,
                key="cui_bubble_size"
            )

        bubble_color = st.selectbox(
            "Cuisine bubble color",
            ["avg_overall_price", "avg_rating", "restaurant_count", "premium_count", "budget_count", "mid_count"],
            index=0,
            key="cui_bubble_color"
        )

        fig = px.scatter(
            bubble_df.dropna(subset=[bubble_x, bubble_y]),
            x=bubble_x,
            y=bubble_y,
            size=bubble_size,
            color=bubble_color,
            hover_name="cuisine_type",
            hover_data=["restaurant_count", "avg_rating", "avg_overall_price", "budget_count", "mid_count", "premium_count"],
            title=f"Cuisine Bubble Chart: {bubble_y} vs {bubble_x}",
        )
        st.plotly_chart(fig, width='stretch')

    st.dataframe(cui, width='stretch', hide_index=True)


def render_restaurant_explorer(df: pd.DataFrame):
    if df.empty:
        render_empty_state()
        return

    show_tier_legend()
    st.subheader("Restaurant Explorer")

    restaurant_names = sorted(df["restaurant_name"].dropna().unique().tolist())
    if not restaurant_names:
        st.warning("No restaurant names available for current filters.")
        return

    selected = st.selectbox("Select restaurant", restaurant_names)
    selected_df = df[df["restaurant_name"] == selected].copy()

    if selected_df.empty:
        st.warning("No restaurant found for current filters.")
        return

    row = selected_df.iloc[0]

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Overall Tier", row["overall_tier"] if pd.notna(row["overall_tier"]) else "NA")
    c2.metric("Overall Avg", format_currency(row["overall_avg"]))
    c3.metric("Rating", round(row["rating"], 1) if pd.notna(row["rating"]) else "NA")
    c4.metric("Seating", int(row["seating"]) if pd.notna(row["seating"]) else "NA")

    left, right = st.columns(2)

    with left:
        details = pd.DataFrame({
            "Field": [
                "Restaurant ID",
                "Restaurant Name",
                "Locality",
                "Cuisine Type",
                "Source",
                "Breakfast Available",
                "Breakfast Tier",
                "Lunch Tier",
                "Dinner Tier",
                "Overall Tier",
            ],
            "Value": [
                row["restaurant_id"],
                row["restaurant_name"],
                row["locality"],
                row["cuisine_type"],
                row["source"],
                row["bfast_available"],
                row["bfast_tier"],
                row["lunch_tier"],
                row["din_tier"],
                row["overall_tier"],
            ],
        })
        st.dataframe(details, width='stretch', hide_index=True)

    with right:
        meal_profile = pd.DataFrame({
            "Meal": ["Breakfast", "Lunch", "Dinner"],
            "Average Price": [row["bfast_avg"], row["lunch_avg"], row["din_avg"]],
        }).dropna()

        fig = px.bar(
            meal_profile,
            x="Meal",
            y="Average Price",
            title=f"Meal Price Profile: {selected}",
        )
        st.plotly_chart(fig, width='stretch')

    st.markdown("### Filtered Restaurant Table")
    display_cols = [
        "restaurant_id", "serial_no", "restaurant_name", "locality", "cuisine_type",
        "source", "rating", "seating",
        "bfast_avg", "lunch_avg", "din_avg", "overall_avg",
        "bfast_tier", "lunch_tier", "din_tier", "overall_tier", "bfast_available"
    ]
    st.dataframe(
        df[display_cols].sort_values(["overall_avg", "rating"], ascending=[False, False]),
        width='stretch',
        hide_index=True,
    )


def render_data_download(df: pd.DataFrame, meta: Dict):
    st.subheader("Data Summary")

    c1, c2, c3 = st.columns(3)
    c1.metric("Sheet Used", meta.get("sheet_used", "DATA"))
    c2.metric("Detected Header Row", meta.get("header_row_detected", "NA"))
    c3.metric("Loaded Records", meta.get("record_count", len(df)))

    st.caption("Only valid restaurant rows from the DATA sheet are included.")

    csv_bytes = df.to_csv(index=False).encode("utf-8")
    st.download_button(
        "Download filtered CSV",
        data=csv_bytes,
        file_name="filtered_restaurant_dashboard_data.csv",
        mime="text/csv",
    )


# =========================================================
# MAIN APP
# =========================================================

# st.title("🍽️ Restaurant Pricing Tier Dashboard")
# st.caption("This app reads only the DATA sheet and auto-detects the restaurant table.")

uploaded_file = st.file_uploader("Upload Excel file", type=["xlsx", "xls"])

if uploaded_file is None:
    st.title("🍽️ Restaurant Pricing Tier Dashboard")
    st.caption("Upload the workbook to begin.")
    st.stop()

try:
    df, meta = load_restaurant_data(uploaded_file, sheet_name="DATA")
except Exception as e:
    st.error(f"Data loading failed: {e}")
    st.stop()

sheet_title = meta.get("title_text") or "Restaurant Pricing Study"
dashboard_title = sheet_title.replace("Study", "Tier Dashboard") if "Study" in sheet_title else f"{sheet_title} Dashboard"

st.title(f"🍽️ {dashboard_title}")
if meta.get("title_text"):
    st.subheader(meta["title_text"])
if meta.get("subtitle_text"):
    st.caption(meta["subtitle_text"])



df_filtered = filter_dataframe(df)

st.success(
    f"Loaded {len(df)} restaurant records from DATA sheet. "
    f"Currently displaying {len(df_filtered)} records."
)

tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs([
    "Overview",
    "Meal Analysis",
    "Locality Analysis",
    "Cuisine Analysis",
    "Restaurant Explorer",
    "Data Summary",
])

with tab1:
    render_overview(df_filtered)

with tab2:
    render_meal_analysis(df_filtered)

with tab3:
    render_locality_analysis(df_filtered)

with tab4:
    render_cuisine_analysis(df_filtered)

with tab5:
    render_restaurant_explorer(df_filtered)

with tab6:
    render_data_download(df_filtered, meta)